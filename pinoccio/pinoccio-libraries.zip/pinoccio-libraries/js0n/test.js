{
	"foo":"b\"a and \\ r",
	"bar":[1,2,3],
	"baz":{"a":"b"},
	"num":123.45,
	"key":"value\n\"newline\"",
	"obj":{"true":true}
}