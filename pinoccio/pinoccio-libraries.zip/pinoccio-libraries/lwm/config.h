#ifndef _LWM_CONFIG_H
#define _LWM_CONFIG_H

// For now, only 256RFR2 is supported
#define HAL_ATMEGA256RFR2
#define PHY_ATMEGARFR2

#endif // _LWM_CONFIG_H
