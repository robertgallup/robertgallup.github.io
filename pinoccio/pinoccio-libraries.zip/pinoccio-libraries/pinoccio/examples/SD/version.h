#define SKETCH_NAME "SD Example"
#define SKETCH_BUILD -1
#define SKETCH_REVISION "unknown"
