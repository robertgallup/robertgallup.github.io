/**************************************************************************\
* Pinoccio Library                                                         *
* https://github.com/Pinoccio/library-pinoccio                             *
* Copyright (c) 2012-2014, Pinoccio Inc. All rights reserved.              *
* ------------------------------------------------------------------------ *
*  This program is free software; you can redistribute it and/or modify it *
*  under the terms of the BSD License as described in license.txt.         *
\**************************************************************************/
#define KEYS_BUNDLE "[\"OVERFLOW\",\"pinoccio\",\"scout\",\"lead\",\"version\",\"family\",\"serial\",\"hardware\",\"build\",\"mesh\",\"scoutid\",\"troopid\",\"routes\",\"rate\",\"power\",\"digital\",\"mode\",\"state\",\"analog\",\"backpacks\",\"list\",\"wifi\",\"connected\",\"hq\",\"temp\",\"current\",\"high\",\"low\",\"uptime\",\"millis\",\"free\",\"random\",\"battery\",\"voltage\",\"charging\",\"vcc\",\"led\",\"torch\",\"daisy\",\"dave\",\"reset\",\"sketch\",\"revision\",\"custom\",\"name\",\"memory\",\"used\",\"large\",\"sleep\",\"channel\",\"f\",\"c\",\"offset\",\"total\"]"
