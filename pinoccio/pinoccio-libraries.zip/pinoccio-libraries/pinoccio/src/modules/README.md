This is where modules are automatically included into the main Pinoccio library so that they can be loaded from ScoutScript anytime with `module.enable()`.

Modules are primarily for including and organizing/exposing utility functions and other arduino libraries via scoutscript on demand without using any memory until loaded.